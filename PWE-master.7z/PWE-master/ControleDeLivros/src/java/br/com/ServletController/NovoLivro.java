/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.ServletController;

import br.com.JavaBeans.Livro;
import br.com.JavaBeans.Usuario;
import br.com.JavaDAO.LivroDAO;
import br.com.JavaDAO.LivroUsuarioDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Set;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Gabriel
 */
public class NovoLivro extends HttpServlet {

public String retorno = "";

    public String executa(HttpServletRequest req, HttpServletResponse resp) throws SQLException{
        String Titulo = req.getParameter("nome");
        String Autor  = req.getParameter("autor");
        String Genero = req.getParameter("genero");
        String Status = req.getParameter("status_leitura");
        
        Livro livro = new Livro();
        livro.setTitulo(Titulo);
        livro.setAutor(Autor);
        livro.setGenero(Genero);
        livro.setStatus_Leitura(Status);
        
        Usuario usuario = new Usuario();
        
        boolean inserir = new LivroDAO().InsereLivro(livro);
        
        boolean inserir2 = new LivroUsuarioDAO().InsereLivroUsuario(usuario, livro);
                
        Collection<Livro> livros = new LivroDAO().buscaTodosOsLivros();

        return "/WEB-INF/paginas/Main.jsp";
    }
}
